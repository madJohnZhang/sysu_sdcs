function caldemo()
%main function
y1=1:0.1:10;
y2=y1.^2;
yy=rsp(y1,y2);
plot(y1,yy);

function y=rsp(y1,y2)
%sub function
H1=y2./y1;
H2=y1./y2;
y=(H1+H2)/2;
