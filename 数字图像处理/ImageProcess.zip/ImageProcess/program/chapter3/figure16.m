RGB=imread('flowers.tif');

figure(1);
imshow(RGB);
figure(2);
Y=rgb2ind(RGB,128);
imshow(Y);