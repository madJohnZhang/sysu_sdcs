imshow debye1.tif
improfile
