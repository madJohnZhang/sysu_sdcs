t=0:0.1:2*pi;
y1=sin(t);
plot(t,y1,':')
hold on
y2=cos(t);
plot(t,y2,'*')
xlabel('Time(0~2\pi)','FontWeight','bold')
text(pi,0,'\leftarrowsin wave')
text(pi/2,0,'\leftarrowcos wave')
hold off
