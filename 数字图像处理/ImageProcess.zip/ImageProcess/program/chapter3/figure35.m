imshow ic.tif
I=imcrop;
