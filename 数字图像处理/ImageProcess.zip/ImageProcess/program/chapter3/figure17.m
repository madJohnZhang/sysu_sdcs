load wmandril;
figure(1);
imshow(X,map);

I=ind2rgb(X,map);
figure(2);
imshow(I);
