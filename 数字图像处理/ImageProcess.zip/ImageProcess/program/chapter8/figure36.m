x=[3 5 12 9]
y=dct(x)
x1=idct(y)
