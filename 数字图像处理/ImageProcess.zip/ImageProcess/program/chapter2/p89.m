k=waitforbuttonpress;
if k==0
  disp('Button Press')
else
  disp('Key press')
end
