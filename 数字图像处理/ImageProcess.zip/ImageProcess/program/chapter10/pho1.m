pho= imread(' nephogram.bmp','bmp');
figure(1);
imshow(pho);

pho1=imnoise(pho,'gaussian',0,20);
figure(2);
imshow(pho1);

pho2=imnoise(pho,'salt & pepper',0.2);
figure(3);
imshow(pho2);

pho3=imnoise(pho,'speckle',20);
figure(4);
imshow(pho3);
