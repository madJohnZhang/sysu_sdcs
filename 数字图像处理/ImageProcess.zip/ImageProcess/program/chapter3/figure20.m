I=imread('saturn.tif');
J=filter2(fspecial('sobel'),I);
K=mat2gray(J);

figure(1);
imshow(I);

figure(2);
imshow(K);