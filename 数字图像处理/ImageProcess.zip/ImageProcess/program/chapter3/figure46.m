imshow flowers.tif
improfile
