

f=boxcar(11);

g=fft(f,512*512);
g=reshape(g,512*256,2);
g=fliplr(g);
g=reshape(g,512*512,1);
x=-(512*256-1)/(512*512):1/(512*512):1/2;
figure(1)
plot(x,abs(g))

hd=ones(11,11);
hd(5:8,5:8)=0

[f1,f2]=freqspace(11,'meshgrid');
figure(2)
mesh(f1,f2,hd);

h=fwind1(hd,boxcar(11));
figure(3),freqz2(h)
load imdemos flower;
figure(4)
imshow(flower);
ff=filter2(h,flower);
figure(5)
imshow(ff);

