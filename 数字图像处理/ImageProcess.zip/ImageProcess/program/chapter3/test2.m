I=imread('C:\ImageProcess\image\bmp\256gray\512x512\lena.bmp');
[x,y]=size(I);
J=zeros(size(I));
J=[I(:,101:y),I(:,1:100)];
K=mat2gray(double(I)+double(J));
figure(3);
imshow(I);
figure(4);
imshow(J);
figure(5);
imshow(K);


%figure(1);
%imhist(I);
%[I2,T]=histeq(I);
%figure(2)
%imshow(I2);