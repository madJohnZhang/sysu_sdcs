RGB=imread('spine.tif');
figure('Position',...
         [100 100 size(RGB,2) size(RGB,1)]);
image(RGB);
set(gca,'Position',[0 0 1 1])
