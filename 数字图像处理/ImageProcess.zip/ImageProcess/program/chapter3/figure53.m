close all;
I=imread('rice.tif');
J=imadjust(I, [0.15 0.9], [0 1]);
imshow(I);
figure, imhist(I, 64);
figure;
imshow(J);
figure, imhist(J, 64);
