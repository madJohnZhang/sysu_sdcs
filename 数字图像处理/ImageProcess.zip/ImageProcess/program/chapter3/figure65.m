close all;
I=imread('spine.tif');
J=histeq(I);
figure;
imshow(I);
figure;
imhist(I);
figure,imshow(J)
figure;
imhist(J);
