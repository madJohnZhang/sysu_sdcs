I=imread('rice.tif');
figure(2);
imshow(I);
figure(1);
imhist(I, 64);
J=histeq(I,64);
figure(3);
imshow(J);
figure(4)
imhist(J)