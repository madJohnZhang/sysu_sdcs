for i=1:3
  for j=1:3
    a(i,j)=i+j;
  end
end
