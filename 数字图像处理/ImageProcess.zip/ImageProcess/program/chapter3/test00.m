I=imread('C:\ImageProcess\image\bmp\256gray\512x512\lena.bmp');
figure(3);
imshow(I);
figure(4)
imhist(I);