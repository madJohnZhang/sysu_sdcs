x=[ 1 2 3
   4 5 6
   7 8 9];
y=[ 1 2 3];
a=sum(y);

z=zeros(a,3);
for i=1:y(1)
   z(i,:)=x(1,:);
end
for i=y(1)+1:[y(2)+y(1)]
   z(i,:)=x(2,:);
end
for i=[y(2)+y(1)]+1:sum(y)
   z(i,:)=x(3,:)
end
