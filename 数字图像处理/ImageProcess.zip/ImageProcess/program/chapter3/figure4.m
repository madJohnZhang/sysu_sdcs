load clown
clims=[10 60];
imagesc(X,clims)
colormap(winter)
