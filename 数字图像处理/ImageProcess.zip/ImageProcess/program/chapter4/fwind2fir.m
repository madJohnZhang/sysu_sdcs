

   [f1,f2] = freqspace(21,'meshgrid');
   Hd = ones(21);
   r = sqrt(f1.^2 + f2.^2);
   Hd(r<0.5) = 0;
   win = fspecial('gaussian',21,2);
   win = win ./ max(win(:));  
   h = fwind2(Hd,win);
   figure(1), freqz2(h)
        
   load imdemos flower;
   ff=filter2(h, flower);
   figure(2)
   imshow(ff);
