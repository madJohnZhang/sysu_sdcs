a=imread('circles.tif');
figure(1)
imshow(a);
b=bwmorph(a, 'spur', Inf);
figure(2)
imshow(b);
