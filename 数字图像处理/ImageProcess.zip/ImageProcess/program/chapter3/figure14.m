load chess
I=ind2gray(X,map);
figure(1);
imshow(X,map);
figure(2);
imshow(I);
