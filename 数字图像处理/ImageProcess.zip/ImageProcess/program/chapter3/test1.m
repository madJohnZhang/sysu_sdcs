I=[ones(64,128);zeros(64,128)];
I=I.*100;
imshow(I)