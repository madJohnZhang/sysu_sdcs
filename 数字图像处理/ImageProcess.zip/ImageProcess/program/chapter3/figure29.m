load mri
montage(D, map)
