clear
load facets;
subplot(221); image(X); colormap(map);
title('ԭʼͼ��');
axis square
init=1992625743; randn('seed', init)
x=X+10*randn(size(X));
subplot(222); image(x); colormap(map);
title('������ͼ��');
axis square
[c, s]=wavedec2(x, 2, 'coif3');
n=[1, 2]
p=[11.20, 22.81];
nc=wthcoef2('h', c, s, n, p, 's');
nc=wthcoef2('v', c, s, n, p, 's');
nc=wthcoef2('d', c, s, n, p, 's');
xx=waverec2(nc, s, 'coif3');
subplot(223); image(xx); colormap(map);
title('ȥ���ͼ��');
axis square;
