cmenu=uicontextmenu;
Hline=plot(1:10,'UIContextMenu',cmenu);
cb1=['set(hline,"LineStyle","--")'];
cb2=['set(hline,"LineStyle",":")'];
cb3=['set(hline,"LineStyle","-")'];
item1=uimenu(cmenu,'Label','dashed','Callback',cb1);
item2=uimenu(cmenu,'Label','dotted','Callback',cb2);
item3=uimenu(cmenu,'Label','solid','Callback',cb3);
