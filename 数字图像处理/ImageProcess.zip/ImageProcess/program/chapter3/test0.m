I=imread('C:\ImageProcess\image\bmp\256gray\512x512\lena.bmp');
I3=imcrop(I)
figure(6)
imshow(I3)