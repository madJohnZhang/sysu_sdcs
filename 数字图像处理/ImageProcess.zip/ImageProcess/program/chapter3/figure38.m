I=imread('tire.tif');
f=inline('max(x(:))');
J=nlfilter(I,[3 3],f);
imshow(I);
figure,imshow(J);
