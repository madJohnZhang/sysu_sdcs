I=imread('spine.tif');
[J,T]=histeq(I);
plot((0:255)/255,T);
