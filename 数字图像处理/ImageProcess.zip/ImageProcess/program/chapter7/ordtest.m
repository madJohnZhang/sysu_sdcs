    a = imread('spine.bmp');
    figure(1)
    imshow(a); 
    
    domain1=ones(3);
    domain2=[ 0 1 0; 1 0 1; 0 1 0];
    domain3=[1 0 1; 0 1 0; 1 0 1];
    
    b1=ordfilt2(a,1,domain1);
    figure(2)
    imshow(b1);
    
    b2=ordfilt2(a,1,domain2);
    figure(3)
    imshow(b2);
    
    b3=ordfilt2(a,1,domain3);
    figure(4)
    imshow(b3);
    
    b4=ordfilt2(a,1,domain1, zeros(3));
    figure(5)
    imshow(b4);
    
    %dilate
    b5=ordfilt2(a,9,domain1);
    figure(6)
    imshow(b5);
    
    b6=ordfilt2(a,4,domain2);
    figure(7)
    imshow(b6);
    
    b7=ordfilt2(a,5,domain3);
    figure(8)
    imshow(b7);
    
    %open
    b8=ordfilt2(b1,9,domain1);
    figure(9)
    imshow(b8);
    
    %close
    b9=ordfilt2(b5,1,domain1);
    figure(10)
    imshow(b9);
    
    %open-close
    b10=ordfilt2(b8,9,domain1);
    b10=ordfilt2(b10,1,domain1);
    figure(11)
    imshow(b10);
    
    %close-open
    b11=ordfilt2(b9,1,domain1);
    b11=ordfilt2(b11,9,domain1);
    figure(12)
    imshow(b11);
    

    
 