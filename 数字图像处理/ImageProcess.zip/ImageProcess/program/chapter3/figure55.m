close all
I=imread('rice.tif');
J=imadjust(I, [0 1], [0 1],0.5);
imshow(I);
figure, imhist(I, 64);
figure;
imshow(J);
figure, imhist(J, 64);
