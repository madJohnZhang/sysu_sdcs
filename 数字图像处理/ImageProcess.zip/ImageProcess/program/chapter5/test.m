indr = (0:5)';
indc = 1:4;

for i=1:2:4
    ind = indc(ones(1,6),i:min(i+2-1,4)) + ...
          indr(:,ones(1,min(i+2-1,4)-i+1));
%    xx = reshape(X(ind),n,min(i+blksz-1,nx)-i+1);
 %   y(i:min(i+blksz-1,nx)) = median(xx);
end
