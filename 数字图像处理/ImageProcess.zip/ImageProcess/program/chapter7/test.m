    clear
    clc
    
    BW0 = imread('brain.bmp');
    figure(1)
    imshow(BW0);
      
    BW1 = im2bw(BW0,0.8);
    figure(2)
    imshow(BW1);
    
    se1=[0 1 1 1; 1 0 1 1; 1 1 0 1; 1 1 1 0];
    se2=ones(3);

    BW2 = dilate(BW1,se1);
    figure(3)
    imshow(BW2);
    
    BW3 = dilate(BW1,se2);
    figure(4)
    imshow(BW3);
      
     
    BW4 = erode(BW1,se1);
    figure(5)
    imshow(BW4);
    
    BW5 = erode(BW1,se2);
    figure(6)
    imshow(BW5);
    
    BW6 = erode(BW2,se1);
    figure(7)
    imshow(BW6);
    
    BW7 = dilate(BW5,se2);
    figure(8)
    imshow(BW7);

    