I=imread('alumgrns.tif');

figure(1);
imshow(I);

figure(2);
X=grayslice(I,16);
imshow(X,hot(16));