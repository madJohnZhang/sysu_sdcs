pp1=0;
pp2=0;
pp3=0;
pp4=0;
pp5=0;
pp6=0;
pp7=0;
pp8=0;
pp9=0;
pp10=0;
pp11=0;
pp12=0;
pp13=0;
pp14=0;
pp15=0;

load fpho1;
l=fpho1
uu=im2double(l);
x=[];
for i=1:256
    x=[x,uu(i,:)]; 
end
net=newsom([0 255],[15]);
net.trainParam.epochs=10000;
net=train(net,x);
plotsom(net.iw{1,1},net.layers{1}.distances);
e=[];
d=[];
we=net.iw{1,1};
for i=1:65536
    a =sim(net,b(i));
    c=find(a);
    if c==1;
       pp1=pp1+1;
    end 
    if c==2;
       pp2=pp2+1;
    end 
    if c==3;
       pp3=pp3+1;
    end 
    if c==4;
       pp4=pp4+1;
    end 
    if c==5;
       pp5=pp5+1;
    end 
    if c==6;
       pp6=pp6+1;
    end 
    if c==7;
       pp7=pp7+1;
    end 
    if c==8;
       pp8=pp8+1;
    end 
    if c==9;
       pp9=pp9+1;
    end
    if c==10;
       pp10=pp10+1;
    end 
    if c==11;
       pp11=pp11+1;
    end 
    if c==12;
       pp12=pp12+1;
    end 
    if c==13;
       pp13=pp13+1;
    end 
    if c==14;
       pp14=pp14+1;
    end 
    if c==15;
       pp15=pp15+1;
    end 
     cc=we(c)*255;
    d=[d,cc];
  end    
 for i=0:255      
     e=[e;d((i*256+1):(i*256+256))];
 end
  f=im2uint8(e/256);
  imshow(f);
