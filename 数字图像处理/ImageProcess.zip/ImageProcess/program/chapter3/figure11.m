X=[1 2 3 4;5 6 7 8;9 10 11 12];
image(X,'XData',[-1 2],'YData',[2 4]);
colormap(colorcube(12))
xlabel x;
ylabel y
