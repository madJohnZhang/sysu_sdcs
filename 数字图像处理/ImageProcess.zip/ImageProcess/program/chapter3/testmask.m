I=imread('C:\ImageProcess\image\bmp\256gray\512x512\lena.bmp');
figure(1);
imshow(I);
mask=zeros(size(I));
mask(247:280,249:349)=ones(34,101);
I1=double(I).*double(mask);
figure(2)
imshow(mat2gray(I1));