clear;
figure(1)
X=imread('lena.bmp');
X=double(X)/255;
imshow(X);

[c,s]=wavedec2(X, 2, 'bior3.7');

ca1=appcoef2(c, s, 'bior3.7', 1);
ch1=detcoef2('h', c, s, 1);
cv1=detcoef2('v', c, s, 1);
cd1=detcoef2('d', c, s, 1);

a1=wrcoef2('a', c, s, 'bior3.7', 1);
h1=wrcoef2('h', c, s, 'bior3.7', 1);
v1=wrcoef2('v', c, s, 'bior3.7', 1);
d1= wrcoef2('d', c, s, 'bior3.7', 1);
c1=[a1, h1; v1, d1];

ca1=appcoef2(c, s, 'bior3.7',1);
ca1=wcodemat(ca1, 440, 'mat', 0);
figure(2)
ca1=0.5*double(ca1);
imagesc(ca1); 

figure(3)
ca2=appcoef2(c, s, 'bior3.7', 2);
ca2=wcodemat(ca2, 440, 'mat', 0);
ca2=0.25*ca2;
imagesc(ca2);
colormap(gray);


