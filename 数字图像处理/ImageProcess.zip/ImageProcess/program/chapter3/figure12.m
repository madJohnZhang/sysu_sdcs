load chess;
RGB=imread('C:\ImageProcess\image\bmp\24bits\640x480\008.bmp');

figure(1);
imshow(RGB);
figure(2);
Y=dither(RGB,map);
imshow(Y,map);