t=-pi:0.1:pi;
trigname=input('Input trig function name:');
switch trigname
   case 'sin'
      plot(t,sin(t))
   case 'cos'
      plot(t,cos(t))
   case 'tan'
      plot(t,tan(t))
   otherwise
      break
end
