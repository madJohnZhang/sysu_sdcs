load trees;
X(1:10,1:10)
map(1:10,1:3)
size(X)
size(map)
imshow(X,map);
%image(X);
%colormap(map)
