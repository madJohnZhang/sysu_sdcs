I=imread('ic.tif');
J=imrotate(I,35,'bilinear');
imshow(I);
figure,imshow(J);