clear
clc
%x=1;
x=[1,2,3,4,8,7,6,5];
y=wmedfilt1(x,[1 1 1],5);
z=medfilt1(x,3,5);
