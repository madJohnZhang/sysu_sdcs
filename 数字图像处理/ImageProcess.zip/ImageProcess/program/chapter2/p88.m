h=waitbar(0,'Please wait...');
for i=1:100
     waitbar(i/100);
end
close(h)
