I=imread('C:\ImageProcess\program\image\Lena.bmp');
%I=imread('C:\ImageProcess\program\chapter8\01hap.bmp');
figure(1);
imshow(I);
F = fft2(I);
F1=abs(F);
high=max(max(F1));
low=min(min(F1));
F1=(F1-low)./(high-low)*128;
F2=angle(F);
F3=real(F);
F4=imag(F);
figure(2);
imshow(F);
figure(3);
imshow(F1);
figure(4);
imshow(F2);
figure(5);
imshow(F3);
figure(6);
imshow(F4);
F5=fftshift(F1);
figure(7);
imshow(F5,128);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I2=ifft2(F1);
high=max(max(I2));
low=min(min(I2));
I2=(I2-low)./(high-low)*128;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I3=ifft2(F2);
high=max(max(I3));
low=min(min(I3));
I3=(I3-low)./(high-low)*128;
figure(8);
imshow(I2,128);
figure(9);
imshow(I3,128);





