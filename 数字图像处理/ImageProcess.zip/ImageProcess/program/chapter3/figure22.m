I=imread('peppers.bmp');
imshow(I,64)
