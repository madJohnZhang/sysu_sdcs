figure
t=0:0.1:4*pi;
y=sin(t);
plot(t,y)
