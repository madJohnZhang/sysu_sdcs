figure(1)
load imdemos saturn2;
imshow(saturn2);
figure(2);
B=fftshift(fft2(saturn2));
imshow(log(abs(B)),[]), colormap(jet(64)), colorbar;
