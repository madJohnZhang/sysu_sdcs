function encode()
%   encode an image 
%   sig--------image signal 
%   re_sig--------reform image signal--fit to VQ
%   siz_word---the size of codeword 
%   siz_book---the size of codebook
%   m_sig------the number of image matrix row
%   n_sig------the number of image matrix column
figure(1);
sig=imread('lena.bmp');
[m_sig,n_sig]=size(sig);
siz_word=4;
siz_book=512;

load codebook4_512;

if m_sig~=n_sig
   error('signal is not fitable for quantization.');
end
if mod(m_sig,siz_word)~=0
   error('signal is also not fitable for quantization.');
end
imshow(sig);
%reshape the image into a vector(siz_word*siz_word*num)
num=m_sig/siz_word;%32
ss=siz_word*siz_word;%64
nn=num*num;%1024
re_sig=[];%64,1024
for i=1:m_sig
   for j=1:m_sig
      f1=floor(i./siz_word);
      m1=mod(i,siz_word);
      if m1==0
         m1=siz_word;
         f1=f1-1;
      end
      f2=floor(j./siz_word);
      m2=mod(j,siz_word);
      if m2==0
         m2=siz_word;
         f2=f2-1;
      end
      re_sig(num*f1+f2+1,siz_word*(m1-1)+m2)=sig(i,j);
   end
end

%encode algorithm
d1=0.0;
for i=1:nn
   codenumber(i)=1;
   min=VectorDistance(siz_word,re_sig(i,:),codebook(1,:));
   for j=2:siz_book
      d=0.0;
      for l=1:siz_word
         d=d+(re_sig(i,l)-codebook(j,l)).^2;
         if d>=min
            break;
         end
      end
      if d<min
         min=d;
         codenumber(i)=j;
      end
   end
   d1=d1+min;
end
inin=codenumber
%decode algorithm

for i=1:nn
   re_sig(i,:)=codebook(codenumber(i),:);
end

%reshape re_sig into re_re_sig

for ni=1:nn
   for nj=1:ss
      f1=floor(ni./num);
      f2=mod(ni,num);
      if f2==0
         f2=num;
         f1=f1-1;
      end
      m1=floor(nj./siz_word)+1;
      m2=mod(nj,siz_word);
      if m2==0
         m2=siz_word;
         m1=m1-1;
      end
      re_re_sig(siz_word*f1+m1,siz_word*(f2-1)+m2)=re_sig(ni,nj);
   end
end

%d=0.0;
%for i=1:m_sig
 %  for j=1:n_sig
  %    d=d+(sig(i,j)-re_re_sig(i,j))^2;
   %end
%end
%dd=256^4/d

figure(2);
imagesc(re_re_sig);
colormap(gray);

