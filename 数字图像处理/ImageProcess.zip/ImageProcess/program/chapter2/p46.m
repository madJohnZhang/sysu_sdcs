for i=1:10
  a(i)=i;
  if i>5
    a(i)=10-i;
  end
end
