if x>=1
   y=10;
elseif x>-1&x<1
   y=0;
else
   y=-10;
end
