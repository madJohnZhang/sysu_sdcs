I=imread('tire.tif');
f=inline('uint8(round(mean2(x)*ones(size(x))))');
J=blkproc(I,[8 8],f);
imshow(I);
figure,imshow(J);
