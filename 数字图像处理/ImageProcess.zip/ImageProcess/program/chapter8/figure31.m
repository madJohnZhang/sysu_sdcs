I=imread('C:\ImageProcess\program\image\Lena.bmp');
figure(1);
imshow(I);
F = fft2(I);
figure(2);
imshow(log(abs(F)),[]);
F1=fftshift(F);
figure(3);
imshow(log(abs(F1)),[]);
