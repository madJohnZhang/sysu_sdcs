t=0:0.1:2*pi;
y1=sin(t);
h_line1=plot(t,y1,':')
hold on
y2=cos(t);
h_line2=plot(t,y2,'*')
h_label=xlabel('Time(0~2\pi)','FontWeight','bold')
h_text1=text(pi,0,'\leftarrowsin wave')
h_text2=text(pi/2,0,'\leftarrowcos wave')
