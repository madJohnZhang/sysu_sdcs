a=imread('circles.tif');
figure(1)
imshow(a);

b0=bwmorph(a, 'bothat');
figure(2)
imshow(b0);

b1=bwmorph(a, 'dilate');
figure(3)
imshow(b1);

b2=bwmorph(a, 'erode');
figure(4)
imshow(b2);

b3=bwmorph(a, 'close', 2);
figure(5)
imshow(b3);

b4=bwmorph(a, 'open', 2);
figure(6)
imshow(b4);

b5=bwmorph(a, 'remove');
figure(7)
imshow(b5);

b6=bwmorph(a, 'skel', Inf);
figure(8)
imshow(b6);

