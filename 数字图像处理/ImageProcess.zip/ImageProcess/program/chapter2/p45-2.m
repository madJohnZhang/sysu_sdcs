sum=0; i=0;
while sum<100
    i=i+1;
    sum=sum+i;
end
