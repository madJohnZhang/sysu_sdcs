[x,y,z]=cylinder;
I=imread('testpat1.tif');
warp(x,y,z,I);
