clear
load detfingr
init=3718025452;
rand('seed',init); Xnoise=X+18*(rand(size(X)));
colormap(map);
subplot(2,2,1); image(wcodemat(X, 192));
title('ԭʼͼ��')
axis square
subplot(2, 2, 2); image(wcodemat(Xnoise, 192));
title('��������ͼ��');
axis square
[c,s]=wavedec2(X, 2, 'sym5');
[thr,sorh, keepapp]=ddencmp('den', 'wv', Xnoise);
[Xdenoise,cxc,lxc,perf0,perfl2]=wdencmp('gbl', c,s,'sym5', 2, thr,sorh, keepapp);
subplot(223); image(Xdenoise);
title('ȥ����ͼ��');
axis square
