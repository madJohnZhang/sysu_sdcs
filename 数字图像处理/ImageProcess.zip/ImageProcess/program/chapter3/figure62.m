close all;
[X]=imread('C:\ImageProcess\image\bmp\256gray\512x512\peppers.bmp');
imshow(X);
pause
I=ind2gray(X,map);
J1=imadjust(I,[],[],0.5);
J2=imadjust(I,[],[],1);
J3=imadjust(I,[],[],2);
figure,imshow(J1)
figure,imshow(J2)
figure,imshow(J3)
