

f=blackman(20);
figure(1);
plot(f);
g=fft(f,512*512);
g=reshape(g,512*256,2);
g=fliplr(g);
g=reshape(g,512*512,1);
x=-(512*256-1)/(512*512):1/(512*512):1/2;
figure(2)
plot(x,abs(g))

f=kaiser(20,1);
figure(3);
plot(f);
g=fft(f,512*512);
g=reshape(g,512*256,2);
g=fliplr(g);
g=reshape(g,512*512,1);
x=-(512*256-1)/(512*512):1/(512*512):1/2;
figure(4)
plot(x,abs(g))

f=bartlett(20);
figure(5);
plot(f);
g=fft(f,512*512);
g=reshape(g,512*256,2);
g=fliplr(g);
g=reshape(g,512*512,1);
x=-(512*256-1)/(512*512):1/(512*512):1/2;
figure(6)
plot(x,abs(g))




