x=[3 5 12 9]
y=fft(x)
x1=ifft(y)
