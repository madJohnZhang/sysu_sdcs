
l=imread('lena.bmp','bmp');
% figure 1

figure;
imshow(l);

j=imnoise(l,'salt & pepper',0.2);
figure;
imshow(j);

j0=all_medfilt2(j,0,[3 3],'symmetric');
figure;
imshow(j0);

j1=all_medfilt2(j,1,[3 3],'symmetric');
figure;
imshow(j1);

j2=all_medfilt2(j,2,[3 3],'symmetric');
figure;
imshow(j2);

j3=all_medfilt2(j,3,[3 3],'symmetric');
figure;
imshow(j3);

j4=all_medfilt2(j,4,[3 3],'symmetric');
figure;
imshow(j4);

j5=all_medfilt2(j,5,[3 3],'symmetric');
figure;
imshow(j5);

j6=all_medfilt2(j,6,[3 3],'symmetric');
figure;
imshow(j6);

j7=all_medfilt2(j,7,[3 3],'symmetric');
figure;
imshow(j7);

j8=all_medfilt2(j,8,[3 3],'symmetric');
figure;
imshow(j8);

j9=all_medfilt2(j,9,[3 3],'symmetric');
figure;
imshow(j9);
