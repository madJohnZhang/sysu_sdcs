I=imread('rice.tif');
figure(2)
imshow(I)
figure(1)
imhist(I, 64)
