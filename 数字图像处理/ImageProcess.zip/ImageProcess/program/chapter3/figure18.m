load woman;

bw1=im2bw(X,map,0.5);
bw2=im2bw(X,map,0.6);

figure(1);
imshow(bw1);
figure(2);
imshow(bw2);
