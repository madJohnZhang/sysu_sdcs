RGB=imread('flowers.tif');

figure(1);
imshow(RGB);
figure(2);
Y=rgb2gray(RGB);
imshow(Y);