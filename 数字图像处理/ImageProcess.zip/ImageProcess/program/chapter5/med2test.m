
l=imread('lena.bmp','bmp');
% figure 1

figure;
imshow(l);

j=imnoise(l,'salt & pepper',0.2);
figure;
imshow(j);

j1=all_medfilt2(j,0,[5 5]);
figure;
imshow(j1);

j2=all_medfilt2(j,1,[5 5]);
figure;
imshow(j2);

j3=all_medfilt2(j,10,[5 5]);
figure;
imshow(j3);
