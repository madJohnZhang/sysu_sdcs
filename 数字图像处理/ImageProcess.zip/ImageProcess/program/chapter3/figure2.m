load trees;
I=double(X)/255;
imagesc(I,[0 1]);
colormap(gray);
figure(2)
imshow(I)