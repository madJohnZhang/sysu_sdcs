load earth;
image(X);
colormap(map);
axis image