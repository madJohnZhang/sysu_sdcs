figure(1);
f = zeros(30,30);
f(5:24,13:17) = 1;
imshow(f,'notruesize')
figure(2);
F = abs(fft2(f));
for i=1:15
   for j=1:15
      a(i,j)=F(16-i,16-j);
   end
end
for i=1:15
   for j=1:15
      a(i+15,j+15)=F(31-i,31-j);
   end
end
for i=1:15
   for j=1:15
      a(i,j+15)=F(16-i,31-j);
   end
end
for i=1:15
   for j=1:15
      a(i+15,j)=F(31-i,16-j);
   end
end

%F2 = log(abs(F));
mesh(a); 
figure(3);
F = fft2(f,256,256);
F2 = log(abs(F));
imshow(F2,[-1 5],'notruesize'); 
colormap(jet); 
colorbar