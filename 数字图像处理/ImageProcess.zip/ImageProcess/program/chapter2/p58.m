t=0:0.1:2*pi;
y=sin(t);
plot(t,y);
xlabel('Time(0~2\pi)','FontWeight','bold');
text(pi,0,'\leftarrowsin(\pi)=0')
