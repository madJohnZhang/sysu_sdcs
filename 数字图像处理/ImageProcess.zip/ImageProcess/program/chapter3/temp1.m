[I,map]=imread('C:\ImageProcess\image\bmp\256color\640x480\001.bmp')
imshow(I,map);