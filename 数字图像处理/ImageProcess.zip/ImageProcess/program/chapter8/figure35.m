close all;
I=imread('C:\ImageProcess\program\image\Lena.bmp');
[sx,sy]=size(I)
figure(1);
imshow(I);
F=ifft2(fft2(I));
F1=abs(F);
F2=mat2gray(F1);
figure(2);
imshow(F2);

I1=fft2(I);
I2=I1;
I1(1:1,1:1)
I1(1:1,1:1)=0;
F=ifft2(I1);
F1=abs(F);
F2=mat2gray(F1);
figure(3);
imshow(F2);

I2=fftshift(I2);
I1=I2;
n=71;
m=(n-1)/2;
I1(sx/2-m:sx/2+m,sy/2-m:sy/2+m)=zeros(n);
F1=ifft2(I1);
F2=abs(F1);
F3=mat2gray(F2);
figure(4);
imshow(F3);

N=35;
I1=zeros(sx,sy);
I1(sx/2-N:sx/2+N,sy/2-N:sy/2+N)=...
    I2(sx/2-N:sx/2+N,sy/2-N:sy/2+N);
F4=ifft2(I1);
F5=abs(F4);
F6=mat2gray(F5);
figure(5);
imshow(F6);

%c=corr2(I,F3)