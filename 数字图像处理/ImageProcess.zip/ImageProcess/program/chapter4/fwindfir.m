

f=boxcar(11);

g=fft(f,512*512);
g=reshape(g,512*256,2);
g=fliplr(g);
g=reshape(g,512*512,1);
x=-(512*256-1)/(512*512):1/(512*512):1/2;
figure(1)
plot(x,abs(g))

hd=ones(11,11);
hd(5:8,5:8)=0

[f1,f2]=freqspace(11,'meshgrid');
figure(2)
mesh(f1,f2,hd);

h=fwind1(hd,triang(11));
figure(3),freqz2(h)
load imdemos flower;
figure(4)
imshow(flower);
ff=filter2(h,flower);
figure(5)
imshow(ff);

[f1,f2] = freqspace(21,'meshgrid');
        Hd = ones(21);
        r = sqrt(f1.^2 + f2.^2);
        Hd((r<0.1) | (r>0.5)) = 0;
        win = fspecial('gaussian',21,2);
        win = win ./ max(win(:));  % Make the maximum window value be 1.
        h = fwind2(Hd,win);
         figure(6), freqz2(h)
