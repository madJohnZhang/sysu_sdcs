I=imread('rice.tif');
BW1=edge(I,'sobel');
BW2=edge(I,'canny');
imshow(BW1);
figure,imshow(BW2)
