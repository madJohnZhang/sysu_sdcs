I=imread('C:\ImageProcess\program\chapter3\01.bmp');
% ͼ���ֵ��
figure(1);
subplot(1,2,1);
imshow(I);
BW=I>54 & I<200;
subplot(1,2,2);
imshow(BW);
  
% �����븯ʴʾ��
Se1=ones(3);
Se2=ones(8);
Face1=erode(BW,Se1); 
Face2=dilate(BW,Se2); 
figure(2);
subplot(1,2,1);
imshow(Face1);
subplot(1,2,2);
imshow(Face2);

% ��������ղ���ʾ��
Se1=ones(3);
Se2=ones(12);
Face3=erode(BW,Se1); 
Face4=dilate(Face3,Se1); 

Face5=dilate(Face4,Se2); 
Face6=erode(Face5,Se2); 
figure(3);
subplot(1,2,1);
imshow(Face4);
subplot(1,2,2);
imshow(Face6);


