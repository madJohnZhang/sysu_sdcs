load pho1;
hood=3;
myfilt = ones(hood)/(hood^2);
fpho1=filter2(myfilt,pho1,'same');
imshow(fpho1);

load pho2;
fpho2=medfilt2(pho1,[ 5 5]);
imshow(fpho2);

load pho3;
hood=3;
fpho3= wiener2(pho3,[hood hood]);;
imshow(fpho3); 
