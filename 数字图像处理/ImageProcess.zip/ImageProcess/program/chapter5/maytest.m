

xx=[1 4 5 2
   7 2 4 2
   6 1 3 3];
W=[2, 5 ,3];
[xm,xn]=size(xx);
[M,N]=size(W);
E=reshape(xx',1,xm*xn);
c=[];
j=1;
k=1;
for i=1:N
   c=[c
      E(ones(1,W(i)),k:xn*j)]
   j=j+1;
   k=k+xn;
end

  