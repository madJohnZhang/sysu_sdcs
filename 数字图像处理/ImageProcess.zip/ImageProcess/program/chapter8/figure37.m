I=imread('C:\ImageProcess\program\image\Lena.bmp');
[sx,sy]=size(I)
figure(1);
imshow(I);
J=dct2(I);
F=idct2(J);
F1=abs(F);
F2=mat2gray(F1);
figure(2);
imshow(log(abs(J)));
figure(3);
imshow(F2);

I1=dct2(I);
I2=I1;
I1(1:10,1:10)=zeros(10);
F1=idct2(I1);
F2=abs(F1);
F3=mat2gray(F2);
figure(4);
imshow(F3);


I1=zeros(sx,sy);
n=50;
I1(1:n,1:n)=I2(1:n,1:n);
F4=idct2(I1);
F5=abs(F4);
F6=mat2gray(F5);
figure(5);
imshow(F6);
