
RGB=imread('C:\ImageProcess\image\bmp\24bits\640x480\001.bmp');
%figure(2)
imshow(RGB)
size(RGB)