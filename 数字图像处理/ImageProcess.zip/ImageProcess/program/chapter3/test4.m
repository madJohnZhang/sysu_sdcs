I=imread('ic.tif');
J=imresize(I,2,'bilinear');
imshow(I);
figure,imshow(J);