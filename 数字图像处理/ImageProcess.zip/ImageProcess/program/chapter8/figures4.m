figure(1)
load imdemos saturn2;
imshow(saturn2);
I=fft2(saturn2);
J=angle(I);
K=abs(I)
figure(2);
imshow(ifft(K));
figure(3);
imshow(ifft(J));
