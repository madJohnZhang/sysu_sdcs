I=imread('rice.tif');
imshow(I)
figure, imcontour(I)
