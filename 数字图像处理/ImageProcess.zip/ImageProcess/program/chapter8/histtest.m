I=imread('C:\ImageProcess\program\image\Lena.bmp');
%I=[1,1,1;2,2,2;3,3,3]
[sx,sy]=size(I);
hist=zeros(1,256);
for i=1:sx
    for j=1:sy
        hist(double(I(i,j))+1)=hist(double(I(i,j))+1)+1;
    end
end
%disp(hist)
figure(1)
stem(0:255,hist)
figure(2)
imhist(I)