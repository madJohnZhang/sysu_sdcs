I=imread('testpat1.tif');
J=filter2([1 2; -1 -2], I);
imshow(J, [])
