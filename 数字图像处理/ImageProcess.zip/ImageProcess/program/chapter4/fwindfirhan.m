

f=hanning(20);
figure(10);
plot(f);
g=fft(f,512*512);
g=reshape(g,512*256,2);
g=fliplr(g);
g=reshape(g,512*512,1);
x=-(512*256-1)/(512*512):1/(512*512):1/2;
figure(1)
plot(x,abs(g))

hd=zeros(20,20);
hd(1:10,1:10)=1;




[f1,f2]=freqspace(20,'meshgrid');
figure(2)
mesh(f1,f2,hd);

h=fwind1(hd,hanning(20));
figure(3),freqz2(h)
load imdemos flower;
figure(4)
imshow(flower);
ff=filter2(h,flower);
figure(5)
imshow(ff);

