load mri
imshow(D(:,:,:,7))
